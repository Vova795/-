import { describe, it, expect } from 'vitest';
import { analyzeQuery } from './analyze';

describe('разбор свободного запроса', () => {
  it('монета 3 раза подряд = 12,5%, тип exact', () => {
    const a = analyzeQuery('Монета выпадет орлом 3 раза подряд');
    expect(a.type).toBe('exact');
    expect(a.probability).not.toBeNull();
    expect(Math.abs((a.probability ?? 0) - 0.125)).toBeLessThan(1e-12);
  });
  it('кубик хотя бы раз за 4 броска считается через 1-(5/6)^4', () => {
    const a = analyzeQuery('Кубик: хотя бы одна шестёрка за 4 броска');
    expect(a.probability).not.toBeNull();
    expect(Math.abs((a.probability ?? 0) - (1 - (5 / 6) ** 4))).toBeLessThan(1e-9);
  });
  it('два кубика сумма 7 = 6/36', () => {
    const a = analyzeQuery('Два кубика дадут сумму 7');
    expect(Math.abs((a.probability ?? 0) - 6 / 36)).toBeLessThan(1e-12);
  });
  it('частота 7 из 10 — statistical с интервалом', () => {
    const a = analyzeQuery('7 успехов из 10 попыток');
    expect(a.type).toBe('statistical');
    expect(Math.abs((a.probability ?? 0) - 0.7)).toBeLessThan(1e-12);
    expect(a.interval).toBeDefined();
    expect(a.interval!.low).toBeLessThan(0.7);
    expect(a.interval!.high).toBeGreaterThan(0.7);
  });
  it('реальный мир: процент НЕ выдумывается', () => {
    const a = analyzeQuery('Будет ли завтра дождь?');
    expect(a.type).toBe('subjective');
    expect(a.probability).toBeNull();
    expect(a.needsData).toBe(true);
  });
  it('пустой и нераспознанный запрос не падает', () => {
    expect(analyzeQuery('').probability).toBeNull();
    expect(analyzeQuery('абракадабра сим салабим').probability).toBeNull();
  });
});
