// ─── Чистая вычислительная логика «Вероятно» ────────────────────────────────
// Никаких обращений к DOM, сети или localStorage здесь нет — только математика.
// Все функции валидируют вход и бросают Error с русским сообщением.

export type EstimateType = 'exact' | 'statistical' | 'subjective';

export const ESTIMATE_LABELS: Record<EstimateType, string> = {
  exact: 'Математически вычисляемая',
  statistical: 'Статистическая оценка по данным',
  subjective: 'Субъективный прогноз',
};

function assertFinite(value: number, name: string): void {
  if (typeof value !== 'number' || !Number.isFinite(value)) {
    throw new Error(`Поле «${name}» должно быть конечным числом.`);
  }
}

export function assertProbability(p: number, name = 'вероятность'): void {
  assertFinite(p, name);
  if (p < 0 || p > 1) {
    throw new Error(`Поле «${name}» должно быть от 0 до 1 (или от 0% до 100%).`);
  }
}

export function assertNonNegativeInt(value: number, name: string): void {
  assertFinite(value, name);
  if (!Number.isInteger(value) || value < 0) {
    throw new Error(`Поле «${name}» должно быть целым числом не меньше 0.`);
  }
}

export function assertPositiveInt(value: number, name: string): void {
  assertFinite(value, name);
  if (!Number.isInteger(value) || value <= 0) {
    throw new Error(`Поле «${name}» должно быть целым положительным числом.`);
  }
}

/** Вероятность одного события: P = m / n. */
export function basicProbability(favorable: number, total: number): number {
  assertNonNegativeInt(favorable, 'благоприятные исходы');
  assertPositiveInt(total, 'все исходы');
  if (favorable > total) {
    throw new Error('Благоприятных исходов не может быть больше, чем всех исходов.');
  }
  return favorable / total;
}

/** Противоположное событие: P(не A) = 1 − P(A). */
export function complement(p: number): number {
  assertProbability(p);
  return 1 - p;
}

/** И для независимых событий: P(A∩B∩…) = P(A)·P(B)·… */
export function independentAnd(probabilities: number[]): number {
  if (probabilities.length === 0) throw new Error('Укажите хотя бы одну вероятность.');
  probabilities.forEach((p, i) => assertProbability(p, `вероятность №${i + 1}`));
  return probabilities.reduce((acc, p) => acc * p, 1);
}

/** ИЛИ для независимых событий: P(A∪B) = 1 − ∏(1 − Pᵢ). Работает для любого числа событий. */
export function independentOr(probabilities: number[]): number {
  if (probabilities.length === 0) throw new Error('Укажите хотя бы одну вероятность.');
  probabilities.forEach((p, i) => assertProbability(p, `вероятность №${i + 1}`));
  return 1 - probabilities.reduce((acc, p) => acc * (1 - p), 1);
}

/** И для зависимых событий: P(A∩B) = P(A) · P(B|A). */
export function dependentAnd(pA: number, pBgivenA: number): number {
  assertProbability(pA, 'P(A)');
  assertProbability(pBgivenA, 'P(B|A)');
  return pA * pBgivenA;
}

/**
 * Выбор без возвращения: вероятность, что все `draws` вытащенных объектов —
 * «благоприятные» (например, все шары красные). draws <= favorable необязательно:
 * если draws > favorable — вероятность 0 по смыслу, но это ошибка ввода для этой постановки.
 */
export function allFavorableWithoutReplacement(total: number, favorable: number, draws: number): number {
  assertPositiveInt(total, 'всего объектов');
  assertNonNegativeInt(favorable, 'благоприятных объектов');
  assertPositiveInt(draws, 'вытаскиваем объектов');
  if (favorable > total) throw new Error('Благоприятных объектов не может быть больше, чем всего.');
  if (draws > total) throw new Error('Нельзя вытащить больше объектов, чем есть всего.');
  if (draws > favorable) return 0;
  let result = 1;
  for (let i = 0; i < draws; i++) {
    result *= (favorable - i) / (total - i);
  }
  return result;
}

/** Число сочетаний C(n, k). Устойчивый мультипликативный алгоритм. */
export function combination(n: number, k: number): number {
  assertNonNegativeInt(n, 'n');
  assertNonNegativeInt(k, 'k');
  if (k > n) return 0;
  const kk = Math.min(k, n - k);
  let result = 1;
  for (let i = 1; i <= kk; i++) {
    result = (result * (n - kk + i)) / i;
  }
  return result;
}

/** Гипергеометрическая вероятность: ровно k успехов при выборе без возвращения. */
export function hypergeometric(
  population: number,
  successesInPopulation: number,
  draws: number,
  k: number,
): number {
  assertPositiveInt(population, 'размер совокупности');
  assertNonNegativeInt(successesInPopulation, 'успехов в совокупности');
  assertPositiveInt(draws, 'размер выборки');
  assertNonNegativeInt(k, 'k');
  if (successesInPopulation > population) throw new Error('Успехов не может быть больше совокупности.');
  if (draws > population) throw new Error('Выборка не может быть больше совокупности.');
  const failures = population - successesInPopulation;
  if (k > successesInPopulation || draws - k > failures) return 0;
  return (combination(successesInPopulation, k) * combination(failures, draws - k)) / combination(population, draws);
}

/** Формула Байеса: P(H|E) = P(E|H)·P(H) / [P(E|H)·P(H) + P(E|¬H)·P(¬H)]. */
export function bayes(prior: number, likelihoodGivenH: number, likelihoodGivenNotH: number): {
  posterior: number;
  marginal: number;
  numerator: number;
} {
  assertProbability(prior, 'априорная вероятность P(H)');
  assertProbability(likelihoodGivenH, 'P(E|H)');
  assertProbability(likelihoodGivenNotH, 'P(E|¬H)');
  const numerator = likelihoodGivenH * prior;
  const marginal = numerator + likelihoodGivenNotH * (1 - prior);
  if (marginal === 0) {
    throw new Error('Свидетельство E невозможно при заданных вероятностях (знаменатель равен 0). Проверьте ввод.');
  }
  return { posterior: numerator / marginal, marginal, numerator };
}

/** Биномиальная вероятность ровно k успехов: P(X=k) = C(n,k) p^k (1−p)^(n−k). */
export function binomialPMF(n: number, k: number, p: number): number {
  assertNonNegativeInt(n, 'число испытаний n');
  assertNonNegativeInt(k, 'число успехов k');
  assertProbability(p, 'вероятность успеха p');
  if (k > n) return 0;
  if (p === 0) return k === 0 ? 1 : 0;
  if (p === 1) return k === n ? 1 : 0;
  // Логарифмический путь для устойчивости при больших n.
  const logP =
    logCombination(n, k) + k * Math.log(p) + (n - k) * Math.log(1 - p);
  return Math.exp(logP);
}

export function logCombination(n: number, k: number): number {
  if (k < 0 || k > n) return -Infinity;
  const kk = Math.min(k, n - k);
  let result = 0;
  for (let i = 1; i <= kk; i++) result += Math.log(n - kk + i) - Math.log(i);
  return result;
}

/** P(X ≤ k) для биномиального распределения. */
export function binomialCDF(n: number, k: number, p: number): number {
  assertNonNegativeInt(n, 'число испытаний n');
  assertNonNegativeInt(k, 'число успехов k');
  assertProbability(p, 'вероятность успеха p');
  if (k >= n) return 1;
  let sum = 0;
  for (let i = 0; i <= k; i++) sum += binomialPMF(n, i, p);
  return Math.min(1, sum);
}

/** P(X ≥ k) для биномиального распределения. */
export function binomialAtLeast(n: number, k: number, p: number): number {
  assertNonNegativeInt(n, 'число испытаний n');
  assertNonNegativeInt(k, 'число успехов k');
  assertProbability(p, 'вероятность успеха p');
  if (k <= 0) return 1;
  if (k > n) return 0;
  return Math.min(1, Math.max(0, 1 - binomialCDF(n, k - 1, p)));
}

/** Полное распределение: массив P(X=k) для k=0..n, plus mean/variance. */
export function binomialDistribution(n: number, p: number): { probs: number[]; mean: number; variance: number; sd: number } {
  assertNonNegativeInt(n, 'число испытаний n');
  assertProbability(p, 'вероятность успеха p');
  if (n > 500) throw new Error('Для наглядности графика n ограничено 500. Для больших n используйте нормальную аппроксимацию.');
  const probs = Array.from({ length: n + 1 }, (_, k) => binomialPMF(n, k, p));
  const mean = n * p;
  const variance = n * p * (1 - p);
  return { probs, mean, variance, sd: Math.sqrt(variance) };
}

/** Хотя бы один успех за n попыток: 1 − (1−p)^n. */
export function atLeastOne(n: number, p: number): number {
  assertNonNegativeInt(n, 'число попыток n');
  assertProbability(p, 'вероятность успеха p');
  if (n === 0) return 0;
  // Устойчиво при маленьких p: 1 - exp(n * log1p(-p))
  return -Math.expm1(n * Math.log1p(-p)) * 1; // = 1-(1-p)^n
}

/** Среднее число попыток до первого успеха (геометрическое распределение): 1/p. */
export function expectedTrialsUntilSuccess(p: number): number {
  assertProbability(p, 'вероятность успеха p');
  if (p === 0) return Infinity;
  return 1 / p;
}

/** Математическое ожидание и дисперсия по таблице исходов. */
export function expectedValue(outcomes: { value: number; probability: number }[]): {
  expected: number;
  variance: number;
  sd: number;
  sumProbabilities: number;
} {
  if (outcomes.length === 0) throw new Error('Добавьте хотя бы один исход.');
  outcomes.forEach((o, i) => {
    assertFinite(o.value, `значение исхода №${i + 1}`);
    assertProbability(o.probability, `вероятность исхода №${i + 1}`);
  });
  const sumProbabilities = outcomes.reduce((s, o) => s + o.probability, 0);
  if (Math.abs(sumProbabilities - 1) > 1e-6) {
    throw new Error(`Сумма вероятностей должна быть равна 1 (100%), сейчас ${formatPercent(sumProbabilities, 2)}. Добавьте недостающие исходы или исправьте вероятности.`);
  }
  const expected = outcomes.reduce((s, o) => s + o.value * o.probability, 0);
  const variance = outcomes.reduce((s, o) => s + o.probability * (o.value - expected) ** 2, 0);
  return { expected, variance, sd: Math.sqrt(variance), sumProbabilities };
}

/** Интервал Вильсона для доли — надёжнее «±1.96·SE» при малых выборках и краях. */
export function wilsonInterval(successes: number, trials: number, z = 1.96): { low: number; high: number } {
  assertNonNegativeInt(successes, 'успехи');
  assertPositiveInt(trials, 'испытания');
  if (successes > trials) throw new Error('Успехов не может быть больше, чем испытаний.');
  const pHat = successes / trials;
  const z2 = z * z;
  const denominator = 1 + z2 / trials;
  const centre = (pHat + z2 / (2 * trials)) / denominator;
  const margin = (z / denominator) * Math.sqrt((pHat * (1 - pHat)) / trials + z2 / (4 * trials * trials));
  return { low: Math.max(0, centre - margin), high: Math.min(1, centre + margin) };
}

export interface FrequencyResult {
  pHat: number;
  low: number;
  high: number;
  standardError: number;
  warnings: string[];
}

/** Частотная оценка доли по данным + предупреждения о надёжности. */
export function frequencyEstimate(successes: number, trials: number): FrequencyResult {
  const { low, high } = wilsonInterval(successes, trials);
  const pHat = successes / trials;
  const standardError = Math.sqrt((pHat * (1 - pHat)) / trials);
  const warnings: string[] = [];
  if (trials < 30) warnings.push(`Малая выборка: всего ${trials} наблюдений. Интервал широкий, оценка легко смещается случайностью.`);
  else if (trials < 100) warnings.push('Выборка умеренная: относитесь к точечной оценке осторожно и смотрите на интервал.');
  if (successes === 0) warnings.push('Успехов не наблюдалось: это не значит, что вероятность равна 0. Смотрите верхнюю границу интервала.');
  if (successes === trials) warnings.push('Успех был во всех наблюдениях: это не значит, что вероятность равна 100%. Смотрите нижнюю границу интервала.');
  if (high - low > 0.3) warnings.push('Интервал шире 30 процентных пунктов — данных недостаточно для точного вывода.');
  return { pHat, low, high, standardError, warnings };
}

/** Один прогон симуляции Бернулли. rng инъектируется для тестируемости. */
export function simulateBernoulli(
  p: number,
  trials: number,
  rng: () => number = Math.random,
): { successes: number; frequency: number; cumulative: number[] } {
  assertProbability(p, 'вероятность успеха p');
  assertPositiveInt(trials, 'число испытаний');
  if (trials > 1_000_000) throw new Error('Слишком много испытаний для браузера (максимум 1 000 000).');
  let successes = 0;
  const cumulative: number[] = [];
  for (let i = 1; i <= trials; i++) {
    if (rng() < p) successes++;
    // Сохраняем не каждую точку при больших n, чтобы график оставался лёгким.
    if (trials <= 2000 || i % Math.ceil(trials / 2000) === 0 || i === trials) {
      cumulative.push(successes / i);
    }
  }
  return { successes, frequency: successes / trials, cumulative };
}

/** Детерминированный генератор для воспроизводимых демо и тестов (mulberry32). */
export function seededRng(seed: number): () => number {
  let a = seed >>> 0;
  return () => {
    a |= 0; a = (a + 0x6d2b79f5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

// ─── Форматирование ──────────────────────────────────────────────────────────

export function formatPercent(p: number, digits = 2): string {
  assertFinite(p, 'вероятность');
  if (p === 0) return '0%';
  if (p === 1) return '100%';
  const value = p * 100;
  // Для очень маленьких вероятностей показываем больше знаков, а не «0%».
  let d = digits;
  if (value > 0 && value < 0.01) d = 4;
  else if (value > 0 && value < 0.1) d = 3;
  else if (value > 0 && value < 1) d = 2;
  return `${value.toFixed(d).replace('.', ',')}%`;
}

export function formatNumber(x: number, digits = 4): string {
  if (!Number.isFinite(x)) return x > 0 ? '∞' : '—';
  return x.toFixed(digits).replace(/\.?0+$/, '').replace('.', ',') || '0';
}

/** Человеческая интерпретация величины вероятности. */
export function interpretProbability(p: number): string {
  if (p === 0) return 'Событие невозможно при заданных условиях.';
  if (p === 1) return 'Событие достоверно при заданных условиях.';
  if (p < 0.01) return 'Очень редко: примерно реже чем 1 раз из 100 при повторении таких же условий.';
  if (p < 0.1) return 'Маловероятно, но вполне возможно при повторении попыток.';
  if (p < 0.35) return 'Скорее не произойдёт, чем произойдёт, но шанс заметный.';
  if (p < 0.5) return 'Меньше половины, но близко к «может быть и так, и так».';
  if (p === 0.5) return 'Ровно как подбрасывание монеты: 50 на 50.';
  if (p < 0.65) return 'Больше половины: скорее произойдёт, чем нет.';
  if (p < 0.9) return 'Вероятно, но с ощутимым шансом обратного исхода.';
  if (p < 0.99) return 'Очень вероятно, хотя обратный исход всё ещё реален.';
  return 'Почти наверняка при заданных условиях, но не гарантия в каждом отдельном случае.';
}

/** «1 раз из N» представление для наглядности. */
export function oneInN(p: number): string | null {
  if (p <= 0 || p >= 1) return null;
  const n = 1 / p;
  if (n < 2) return null;
  if (n >= 1000) return `примерно 1 раз из ${Math.round(n).toLocaleString('ru-RU')}`;
  return `примерно 1 раз из ${formatNumber(n, 1)}`;
}
