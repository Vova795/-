import { describe, it, expect } from 'vitest';
import {
  basicProbability,
  complement,
  independentAnd,
  independentOr,
  dependentAnd,
  allFavorableWithoutReplacement,
  combination,
  hypergeometric,
  bayes,
  binomialPMF,
  binomialCDF,
  binomialAtLeast,
  binomialDistribution,
  atLeastOne,
  expectedTrialsUntilSuccess,
  expectedValue,
  wilsonInterval,
  frequencyEstimate,
  simulateBernoulli,
  seededRng,
  formatPercent,
  interpretProbability,
} from './probability';

const close = (a: number, b: number, eps = 1e-9) => expect(Math.abs(a - b)).toBeLessThan(eps);

describe('базовая вероятность', () => {
  it('m/n', () => {
    close(basicProbability(1, 6), 1 / 6);
    close(basicProbability(0, 6), 0);
    close(basicProbability(6, 6), 1);
  });
  it('отвергает m > n и n = 0', () => {
    expect(() => basicProbability(7, 6)).toThrow();
    expect(() => basicProbability(1, 0)).toThrow();
    expect(() => basicProbability(-1, 6)).toThrow();
    expect(() => basicProbability(1.5, 6)).toThrow();
  });
  it('дополнение до 1', () => {
    close(complement(0.3), 0.7);
    close(complement(0), 1);
    expect(() => complement(1.2)).toThrow();
    expect(() => complement(-0.1)).toThrow();
    expect(() => complement(NaN)).toThrow();
  });
});

describe('независимые и зависимые события', () => {
  it('AND независимых = произведение', () => {
    close(independentAnd([0.5, 0.5]), 0.25);
    close(independentAnd([0.5, 0.5, 0.5]), 0.125);
    close(independentAnd([1, 0.3]), 0.3);
  });
  it('OR независимых', () => {
    close(independentOr([0.5, 0.5]), 0.75);
    close(independentOr([0.1]), 0.1);
    close(independentOr([0, 0]), 0);
    close(independentOr([1, 0.2]), 1);
  });
  it('пустой список — ошибка', () => {
    expect(() => independentAnd([])).toThrow();
    expect(() => independentOr([])).toThrow();
  });
  it('зависимое AND через условную', () => {
    close(dependentAnd(0.5, 0.4), 0.2);
  });
  it('без возвращения: два красных из 5 при 3 красных = 3/5·2/4', () => {
    close(allFavorableWithoutReplacement(5, 3, 2), 0.3);
    close(allFavorableWithoutReplacement(52, 4, 1), 4 / 52);
    close(allFavorableWithoutReplacement(5, 2, 3), 0);
    expect(() => allFavorableWithoutReplacement(5, 3, 6)).toThrow();
  });
});

describe('сочетания и гипергеометрия', () => {
  it('C(n,k)', () => {
    expect(combination(6, 2)).toBe(15);
    expect(combination(52, 5)).toBe(2598960);
    expect(combination(10, 0)).toBe(1);
    expect(combination(10, 10)).toBe(1);
    expect(combination(5, 7)).toBe(0);
  });
  it('гипергеометрия суммируется в 1', () => {
    let s = 0;
    for (let k = 0; k <= 3; k++) s += hypergeometric(10, 4, 3, k);
    close(s, 1, 1e-9);
  });
});

describe('Байес', () => {
  it('классический пример с редкой болезнью', () => {
    // P(H)=1%, чувствительность 99%, ложноположительный 5% → ≈16.7%
    const r = bayes(0.01, 0.99, 0.05);
    close(r.posterior, 0.0099 / (0.0099 + 0.05 * 0.99), 1e-12);
    expect(r.posterior).toBeGreaterThan(0.16);
    expect(r.posterior).toBeLessThan(0.17);
  });
  it('posterior между 0 и 1, крайние случаи', () => {
    close(bayes(0.5, 1, 0).posterior, 1);
    close(bayes(0, 0.9, 0.1).posterior, 0);
    expect(() => bayes(0.5, 0, 0)).toThrow();
    expect(() => bayes(1.5, 0.5, 0.5)).toThrow();
  });
  it('неинформативное свидетельство не меняет prior', () => {
    close(bayes(0.3, 0.5, 0.5).posterior, 0.3);
  });
});

describe('биномиальное распределение', () => {
  it('PMF: 2 орла из 3 честных бросков = 3/8', () => {
    close(binomialPMF(3, 2, 0.5), 0.375);
    close(binomialPMF(10, 0, 0.5), 0.5 ** 10);
    close(binomialPMF(5, 7, 0.5), 0);
  });
  it('границы p=0 и p=1', () => {
    close(binomialPMF(10, 0, 0), 1);
    close(binomialPMF(10, 3, 0), 0);
    close(binomialPMF(10, 10, 1), 1);
  });
  it('распределение суммируется в 1', () => {
    const d = binomialDistribution(12, 0.3);
    close(d.probs.reduce((a, b) => a + b, 0), 1, 1e-9);
    close(d.mean, 3.6);
    close(d.variance, 12 * 0.3 * 0.7);
  });
  it('CDF и AtLeast дополняют друг друга', () => {
    close(binomialCDF(10, 10, 0.4), 1);
    close(binomialAtLeast(10, 0, 0.4), 1);
    close(binomialAtLeast(10, 11, 0.4), 0);
    close(binomialCDF(10, 3, 0.4) + binomialAtLeast(10, 4, 0.4), 1, 1e-9);
  });
});

describe('хотя бы один успех', () => {
  it('1-(1-p)^n', () => {
    close(atLeastOne(1, 0.5), 0.5);
    close(atLeastOne(2, 0.5), 0.75);
    close(atLeastOne(0, 0.5), 0);
    close(atLeastOne(10, 0), 0);
    close(atLeastOne(10, 1), 1);
    // 100 попыток по 1% ≈ 63.4%, а не 100%
    expect(atLeastOne(100, 0.01)).toBeGreaterThan(0.63);
    expect(atLeastOne(100, 0.01)).toBeLessThan(0.64);
  });
  it('среднее ожидание первого успеха', () => {
    close(expectedTrialsUntilSuccess(0.5), 2);
    expect(expectedTrialsUntilSuccess(0)).toBe(Infinity);
  });
});

describe('матожидание', () => {
  it('кубик: E=3.5', () => {
    const outcomes = [1, 2, 3, 4, 5, 6].map((v) => ({ value: v, probability: 1 / 6 }));
    const r = expectedValue(outcomes);
    close(r.expected, 3.5);
    expect(r.sd).toBeGreaterThan(1.7);
    expect(r.sd).toBeLessThan(1.72);
  });
  it('сумма вероятностей ≠ 1 — понятная ошибка', () => {
    expect(() => expectedValue([{ value: 1, probability: 0.5 }])).toThrow(/Сумма вероятностей/);
  });
});

describe('частотная оценка и интервал Вильсона', () => {
  it('7 из 10 → 70% внутри интервала', () => {
    const r = frequencyEstimate(7, 10);
    close(r.pHat, 0.7);
    expect(r.low).toBeLessThan(0.7);
    expect(r.high).toBeGreaterThan(0.7);
    expect(r.warnings.length).toBeGreaterThan(0); // малая выборка
  });
  it('0 успехов ≠ 0%: верхняя граница > 0', () => {
    const r = wilsonInterval(0, 20);
    expect(r.low).toBe(0);
    expect(r.high).toBeGreaterThan(0.1);
  });
  it('большая выборка → узкий интервал без предупреждения о малости', () => {
    const r = frequencyEstimate(500, 1000);
    expect(r.high - r.low).toBeLessThan(0.07);
    expect(r.warnings).toHaveLength(0);
  });
  it('успехов больше испытаний — ошибка', () => {
    expect(() => frequencyEstimate(11, 10)).toThrow();
  });
});

describe('симуляция', () => {
  it('детерминирована при фиксированном seed', () => {
    const a = simulateBernoulli(0.5, 1000, seededRng(42));
    const b = simulateBernoulli(0.5, 1000, seededRng(42));
    expect(a.successes).toBe(b.successes);
    expect(a.frequency).toBeGreaterThan(0.4);
    expect(a.frequency).toBeLessThan(0.6);
  });
  it('p=0 и p=1', () => {
    expect(simulateBernoulli(0, 100, seededRng(1)).successes).toBe(0);
    expect(simulateBernoulli(1, 100, seededRng(1)).successes).toBe(100);
  });
});

describe('форматирование', () => {
  it('проценты по-русски', () => {
    expect(formatPercent(0.5)).toContain('50');
    expect(formatPercent(0)).toBe('0%');
    expect(formatPercent(1)).toBe('100%');
    expect(formatPercent(0.0001)).not.toBe('0%');
  });
  it('интерпретация не врёт на краях', () => {
    expect(interpretProbability(0)).toContain('невозможно');
    expect(interpretProbability(1)).toContain('достоверно');
    expect(interpretProbability(0.5)).toContain('50 на 50');
  });
});
