// История хранится ТОЛЬКО локально, в localStorage браузера пользователя.
// На сервер ничего не отправляется.
import type { EstimateType } from './probability';

export interface HistoryEntry {
  id: string;
  createdAt: number;
  title: string;
  type: EstimateType;
  summary: string;
  percentText: string;
}

const KEY = 'veroyatno-history-v1';
const MAX = 100;

export function loadHistory(): HistoryEntry[] {
  try {
    const raw = localStorage.getItem(KEY);
    if (!raw) return [];
    const parsed = JSON.parse(raw) as HistoryEntry[];
    return Array.isArray(parsed) ? parsed.slice(0, MAX) : [];
  } catch {
    return [];
  }
}

export function saveHistory(entries: HistoryEntry[]): void {
  try {
    localStorage.setItem(KEY, JSON.stringify(entries.slice(0, MAX)));
  } catch {
    // Переполненное/запрещённое хранилище не должно ломать расчёты.
  }
}

export function makeEntry(title: string, type: EstimateType, summary: string, percentText: string): HistoryEntry {
  return {
    id: `${Date.now()}-${Math.random().toString(36).slice(2, 8)}`,
    createdAt: Date.now(),
    title,
    type,
    summary,
    percentText,
  };
}
