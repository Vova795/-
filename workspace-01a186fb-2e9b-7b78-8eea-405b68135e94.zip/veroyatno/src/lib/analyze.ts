// ─── Разбор свободного запроса пользователя ──────────────────────────────────
// Честное правило: точный процент даём только там, где есть математическая
// модель или данные пользователя. Для реального мира без данных процент
// НЕ выдумываем — объясняем, что нужно, и предлагаем калькулятор/оценку.

import {
  atLeastOne,
  bayes,
  binomialPMF,
  frequencyEstimate,
  basicProbability,
  formatPercent,
  interpretProbability,
  type EstimateType,
} from './probability';

export interface Analysis {
  type: EstimateType;
  title: string;
  /** null — честно посчитать нельзя без дополнительных данных */
  probability: number | null;
  headline: string;
  explanation: string;
  formula: string;
  inputs: string[];
  steps: string[];
  assumptions: string[];
  limitations: string[];
  warnings: string[];
  suggestedCalculator: string | null;
  needsData: boolean;
  interval?: { low: number; high: number };
}

const REAL_WORLD_WORDS = [
  'погод', 'дожд', 'снег завтра', 'завтра', 'матч', 'футбол', 'выиграет', 'победит',
  'акци', 'биткоин', 'курс', 'доллар', 'рубл', 'выборы', 'президент', 'заболе',
  'болезн', 'рак', 'covid', 'ковид', 'грипп', 'похуде', 'экзамен сдам', 'сдам экзамен',
  'устроюсь', 'зарплат', 'ипоте', 'цены вырастут', 'инфляц',
];

function nums(text: string): number[] {
  const m = text.replace(',', '.').match(/\d+(?:\.\d+)?/g);
  return m ? m.map(Number) : [];
}

function percents(text: string): number[] {
  const m = [...text.replace(',', '.').matchAll(/(\d+(?:\.\d+)?)\s*%/g)];
  return m.map((x) => Number(x[1]) / 100);
}

function base(opts: Partial<Analysis> & { title: string; headline: string; explanation: string }): Analysis {
  return {
    type: 'subjective',
    probability: null,
    formula: '—',
    inputs: [],
    steps: [],
    assumptions: [],
    limitations: [],
    warnings: [],
    suggestedCalculator: null,
    needsData: false,
    ...opts,
  };
}

export function analyzeQuery(raw: string): Analysis {
  const q = raw.trim().toLowerCase();
  if (!q) {
    return base({
      title: 'Пустой запрос',
      headline: 'Опишите событие своими словами',
      explanation: 'Например: «Монета выпадет орлом 3 раза подряд» или «7 успехов из 10 попыток».',
    });
  }
  const numbers = nums(q);
  const pcts = percents(q);

  // ── 1. Хотя бы один успех ──
  if (/хотя бы (один|одна|одно|раз)/.test(q)) {
    // ищем p: процент или «1 из N» контекст, и n: «из N попыток / за N раз»
    let p: number | null = pcts[0] ?? null;
    let n: number | null = null;
    const nMatch = q.match(/(?:за|из|на протяжении)\s+(\d+)\s*(?:попыт|раз|брос|испытан|дн|игр)/);
    if (nMatch) n = Number(nMatch[1]);
    if (p === null) {
      // «кубик ... хотя бы раз за 4 броска» → p одного броска 1/6
      if (/кубик|кость|шестёрк|шестерк/.test(q)) p = 1 / 6;
      if (/монет|орёл|орел|решк/.test(q)) p = 0.5;
    }
    if (p !== null && n !== null && n > 0) {
      const prob = atLeastOne(n, p);
      return base({
        type: 'exact',
        title: 'Хотя бы один успех',
        probability: prob,
        headline: `${formatPercent(prob)} — хотя бы один раз за ${n} попыток`,
        explanation: `${interpretProbability(prob)} Считаем через противоположное событие: проще найти шанс, что успеха не будет ни разу, и вычесть из 100%.`,
        formula: `P(хотя бы один) = 1 − (1 − p)ⁿ = 1 − (1 − ${p})^${n}`,
        inputs: [`Шанс успеха в одной попытке p = ${formatPercent(p)}`, `Число попыток n = ${n}`],
        steps: [
          `Шанс неудачи в одной попытке: 1 − p = ${formatPercent(1 - p)}.`,
          `Все ${n} попыток неудачны (независимость): (${formatPercent(1 - p)})^${n} = ${formatPercent((1 - p) ** n)}.`,
          `Итого: 1 − ${formatPercent((1 - p) ** n)} = ${formatPercent(prob)}.`,
        ],
        assumptions: ['Попытки независимы, шанс p не меняется от попытки к попытке.'],
        limitations: ['Если попытки влияют друг на друга или p меняется, модель нужно менять.'],
        suggestedCalculator: 'atleast',
      });
    }
    return base({
      type: 'exact',
      title: 'Хотя бы один успех',
      headline: 'Не хватает данных: нужен шанс одной попытки и их число',
      explanation: 'Напишите, например: «Хотя бы один раз за 10 попыток, если шанс одной попытки 10%». Или откройте калькулятор ниже.',
      formula: 'P = 1 − (1 − p)ⁿ',
      needsData: true,
      suggestedCalculator: 'atleast',
    });
  }

  // ── 2. Байес / тест / условная ──
  if (/байес|условн|тест.*(точн|болезн)|чувствительн|ложнополож/.test(q) && pcts.length >= 3) {
    try {
      const [prior, lh, lhNot] = pcts;
      const r = bayes(prior, lh, lhNot);
      return base({
        type: 'exact',
        title: 'Вероятность по формуле Байеса',
        probability: r.posterior,
        headline: `${formatPercent(r.posterior)} после получения свидетельства`,
        explanation: `До свидетельства было ${formatPercent(prior)}. Свидетельство встречается и при верной гипотезе, и без неё — поэтому итог сильно зависит от базовой частоты. ${interpretProbability(r.posterior)}`,
        formula: 'P(H|E) = P(E|H)·P(H) / [P(E|H)·P(H) + P(E|¬H)·P(¬H)]',
        inputs: [`P(H) до свидетельства = ${formatPercent(prior)}`, `P(E|H) = ${formatPercent(lh)}`, `P(E|¬H) = ${formatPercent(lhNot)}`],
        steps: [`Числитель: ${formatPercent(lh)} × ${formatPercent(prior)} = ${formatPercent(r.numerator)}.`, `Полная вероятность свидетельства: ${formatPercent(r.marginal)}.`, `Итог: ${formatPercent(r.posterior)}.`],
        assumptions: ['Введённые три вероятности описывают именно вашу ситуацию и получены из надёжного источника.'],
        limitations: ['Ошибка в априорной вероятности (базовой частоте) сильнее всего искажает результат.'],
        warnings: prior < 0.05 ? ['Гипотеза редкая (prior < 5%): даже точный тест часто даёт ложные срабатывания — итог может быть намного ниже интуитивного.'] : [],
        suggestedCalculator: 'bayes',
      });
    } catch { /* упадём в ветку ниже */ }
  }
  if (/байес|условн/.test(q)) {
    return base({
      type: 'exact',
      title: 'Условная вероятность и Байес',
      headline: 'Нужны три числа — откройте калькулятор Байеса',
      explanation: 'Чтобы обновить вероятность после нового факта, нужны: вероятность гипотезы до факта P(H), шанс такого факта при верной гипотезе P(E|H) и шанс факта без гипотезы P(E|¬H). Без базовой частоты ответ будет обманчивым.',
      formula: 'P(H|E) = P(E|H)·P(H) / P(E)',
      needsData: true,
      suggestedCalculator: 'bayes',
    });
  }

  // ── 3. Монета: подряд / ровно k раз ──
  if (/монет|орёл|орел|решк/.test(q)) {
    const подряд = q.match(/(\d+)\s*раз[а-яё]*\s+подряд/);
    if (подряд) {
      const n = Number(подряд[1]);
      if (n >= 1 && n <= 100) {
        const prob = 0.5 ** n;
        return base({
          type: 'exact',
          title: `Монета: ${n} раз подряд одна сторона`,
          probability: prob,
          headline: `${formatPercent(prob)}`,
          explanation: `Каждый бросок честной монеты независим: шансы перемножаются. ${interpretProbability(prob)}`,
          formula: `P = (1/2)^${n}`,
          inputs: ['Монета честная: орёл и решка по 50%', `Подряд нужно: ${n}`],
          steps: [`(1/2)^${n} = ${formatPercent(prob)}.`],
          assumptions: ['Монета честная и броски независимы.'],
          limitations: ['Прошлые броски не влияют на будущие: после 5 орлов шанс следующего орла всё ещё 50%.'],
          warnings: ['Частая ошибка — «ошибка игрока»: серия в прошлом не делает противоположный исход «должным».'],
          suggestedCalculator: 'basic',
        });
      }
    }
    const ровно = q.match(/(\d+)\s*(?:орл|успех|раз)/);
    const всего = q.match(/(?:из|за)\s+(\d+)\s*(?:брос|раз|попыт)/);
    if (ровно && всего) {
      const k = Number(ровно[1]); const n = Number(всего[1]);
      if (n >= 1 && n <= 200 && k <= n) {
        const prob = binomialPMF(n, k, 0.5);
        return base({
          type: 'exact',
          title: `Монета: ровно ${k} из ${n}`,
          probability: prob,
          headline: `${formatPercent(prob)} — ровно ${k} успехов из ${n}`,
          explanation: `${interpretProbability(prob)} Порядок не важен: считаем все способы получить именно ${k} успехов.`,
          formula: `P(X=${k}) = C(${n},${k}) · (1/2)^${n}`,
          inputs: [`Испытаний n = ${n}`, `Успехов k = ${k}`, 'p = 50% (честная монета)'],
          assumptions: ['Монета честная, испытания независимые.'],
          limitations: [],
          suggestedCalculator: 'binomial',
        });
      }
    }
    return base({
      type: 'exact',
      title: 'Подбрасывание монеты',
      probability: 0.5,
      headline: '50% — орёл или решка в одном броске',
      explanation: 'Для честной монеты у одного броска два равновозможных исхода. Уточните запрос («3 раза подряд», «ровно 2 орла из 5 бросков»), чтобы посчитать серию.',
      formula: 'P = 1 / 2',
      inputs: ['Один бросок честной монеты'],
      assumptions: ['Монета честная.'],
      limitations: ['Для реальной монеты возможна крошечная асимметрия — на практике ей пренебрегают.'],
      suggestedCalculator: 'binomial',
    });
  }

  // ── 4. Кубик ──
  if (/кубик|игральн|кость|граней/.test(q)) {
    const сумма = q.match(/сумм[а-яё]*\s+(\d+)/);
    if (/два|2\s*кубик|двух/.test(q) && сумма) {
      const target = Number(сумма[1]);
      if (target >= 2 && target <= 12) {
        let fav = 0;
        for (let a = 1; a <= 6; a++) for (let b = 1; b <= 6; b++) if (a + b === target) fav++;
        const prob = fav / 36;
        return base({
          type: 'exact',
          title: `Два кубика: сумма ${target}`,
          probability: prob,
          headline: `${formatPercent(prob)} (${fav} из 36 комбинаций)`,
          explanation: `У двух кубиков 36 равновозможных пар. Сумму ${target} дают ${fav} пар. ${interpretProbability(prob)}`,
          formula: `P = ${fav} / 36`,
          inputs: ['Два честных шестигранных кубика', `Нужная сумма: ${target}`],
          assumptions: ['Кубики честные и независимые.'],
          limitations: [],
          suggestedCalculator: 'basic',
        });
      }
    }
    const граней = q.match(/(\d+)\s*гран/);
    const sides = граней ? Number(граней[1]) : 6;
    if (sides >= 2 && sides <= 1000) {
      const prob = 1 / sides;
      return base({
        type: 'exact',
        title: `Кубик: конкретное значение`,
        probability: prob,
        headline: `${formatPercent(prob)} — одно значение из ${sides}`,
        explanation: `У честного кубика с ${sides} гранями каждое значение равновозможно. ${interpretProbability(prob)} Уточните («два кубика сумма 7», «хотя бы раз за 4 броска»), если нужна другая постановка.`,
        formula: `P = 1 / ${sides}`,
        inputs: [`Граней: ${sides}`, 'Нужно одно конкретное значение'],
        assumptions: ['Кубик честный.'],
        limitations: [],
        suggestedCalculator: 'basic',
      });
    }
  }

  // ── 5. Частота по данным: «7 из 10», «45 успехов из 100 попыток» ──
  const freqMatch = q.match(/(\d+)\s*(?:успе[а-яё]*|раз|случа[а-яё]*)?\s*из\s+(\d+)/);
  if (freqMatch && !/кубик|монет/.test(q)) {
    const fav = Number(freqMatch[1]); const total = Number(freqMatch[2]);
    if (total > 0 && fav <= total) {
      try {
        const r = frequencyEstimate(fav, total);
        return base({
          type: 'statistical',
          title: 'Оценка по наблюдаемой частоте',
          probability: r.pHat,
          headline: `${formatPercent(r.pHat)} по данным (${fav} из ${total}), 95% интервал: ${formatPercent(r.low)}–${formatPercent(r.high)}`,
          explanation: `Доля успехов в ваших данных — ${formatPercent(r.pHat)}. Но истинная вероятность может отличаться: интервал Вильсона показывает диапазон, совместимый с такими данными. Чем меньше наблюдений, тем шире интервал.`,
          formula: 'p̂ = успехи / испытания; интервал — Вильсона (95%)',
          inputs: [`Успехов: ${fav}`, `Испытаний: ${total}`],
          steps: [`p̂ = ${fav} / ${total} = ${formatPercent(r.pHat)}.`, `95% интервал Вильсона: от ${formatPercent(r.low)} до ${formatPercent(r.high)}.`],
          assumptions: ['Наблюдения независимы и условия не менялись.', 'Выборка не смещена (собрана не только из «удобных» случаев).'],
          limitations: ['Это оценка по прошлым данным, а не гарантия на будущее.'],
          warnings: r.warnings,
          interval: { low: r.low, high: r.high },
          suggestedCalculator: 'frequency',
        });
      } catch { /* ниже */ }
    }
  }

  // ── 6. Простая доля «M из N исходов» без данных-контекста ──
  if (/благоприятн|исход|шаров|карт/.test(q) && numbers.length >= 2) {
    const [fav, total] = numbers;
    if (total > 0 && fav <= total) {
      const prob = basicProbability(fav, total);
      return base({
        type: 'exact',
        title: 'Доля благоприятных исходов',
        probability: prob,
        headline: `${formatPercent(prob)} (${fav} из ${total})`,
        explanation: `${interpretProbability(prob)} Все исходы считаем равновозможными.`,
        formula: `P = ${fav} / ${total}`,
        inputs: [`Благоприятных: ${fav}`, `Всего: ${total}`],
        assumptions: ['Все исходы равновозможны, выбор случаен.'],
        limitations: ['Если исходы не равновозможны, нужна другая модель.'],
        suggestedCalculator: 'basic',
      });
    }
  }

  // ── 7. Реальный мир без вычислимой модели → честный отказ от выдуманного % ──
  if (REAL_WORLD_WORDS.some((w) => q.includes(w))) {
    return base({
      type: 'subjective',
      title: 'Прогноз о реальном мире',
      probability: null,
      headline: 'Точный процент здесь посчитать нельзя — и это честный ответ',
      explanation:
        'У такого события нет формулы как у кубика и нет ваших данных для статистики. Любой «точный» процент без источника был бы выдумкой. Что можно сделать: 1) найти базовую частоту (как часто такое случалось в похожих ситуациях), 2) ввести её в калькулятор частоты или Байеса, 3) или собрать субъективную оценку ниже — с диапазоном и явными основаниями.',
      formula: 'Нужна базовая частота: сколько раз событие происходило из скольких похожих случаев',
      inputs: ['Ваш запрос описывает реальный мир, а не модель с известными шансами'],
      steps: ['Сформулируйте похожие прошлые случаи.', 'Посчитайте, в какой доле из них событие произошло.', 'Введите «успехи из испытаний» сюда или в калькулятор частоты.'],
      assumptions: [],
      limitations: ['Прошлая частота работает, только если условия похожи на прошлые.', 'Редкие и уникальные события почти не имеют надёжной статистики.'],
      warnings: ['Остерегайтесь сайтов, которые без источника и данных показывают «точную» вероятность таких событий.'],
      needsData: true,
      suggestedCalculator: 'frequency',
    });
  }

  // ── 8. Общий случай ──
  return base({
    type: 'subjective',
    title: 'Запрос не похож на вычислимую задачу',
    headline: 'Уточните задачу или выберите калькулятор',
    explanation:
      'Я умею точно считать задачи с известной моделью (монета, кубик, урна, серия попыток), оценивать долю по вашим данным («7 из 10») и обновлять вероятность по Байесу. Напишите, например: «кубик 6 хотя бы раз за 4 броска», «монета орёл 3 раза подряд», «8 успехов из 20 попыток». Для событий реального мира нужны исходные данные — выдуманный процент я не покажу.',
    formula: '—',
    needsData: true,
    suggestedCalculator: 'basic',
  });
}

export const EXAMPLE_QUERIES: { query: string; hint: string }[] = [
  { query: 'Монета выпадет орлом 3 раза подряд', hint: 'точная · серия' },
  { query: 'Кубик: хотя бы одна шестёрка за 4 броска', hint: 'точная · хотя бы раз' },
  { query: 'Два кубика дадут сумму 7', hint: 'точная · комбинации' },
  { query: '7 успехов из 10 попыток', hint: 'по данным · с интервалом' },
  { query: 'Хотя бы один раз за 20 попыток, если шанс попытки 5%', hint: 'точная · серия' },
  { query: 'Будет ли завтра дождь?', hint: 'реальный мир · нужны данные' },
];
