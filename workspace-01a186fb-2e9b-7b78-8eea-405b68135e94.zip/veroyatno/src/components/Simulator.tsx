import { useState, type FormEvent } from 'react';
import { simulateBernoulli, formatPercent, formatNumber } from '../lib/probability';
import { ConvergenceChart } from './Charts';
import { ResultCard, type CalcOutput } from './ResultCard';

const PRESETS = [
  { id: 'coin', label: 'Монета (50%)', p: 50 },
  { id: 'die6', label: 'Шестёрка на кубике (≈16,7%)', p: 16.67 },
  { id: 'rare', label: 'Редкое событие (5%)', p: 5 },
];

export function Simulator({ onSave }: { onSave: (o: CalcOutput) => void }) {
  const [preset, setPreset] = useState('coin');
  const [customP, setCustomP] = useState('30');
  const [trials, setTrials] = useState('1000');
  const [error, setError] = useState<string | null>(null);
  const [result, setResult] = useState<CalcOutput | null>(null);
  const [cumulative, setCumulative] = useState<number[]>([]);
  const [theory, setTheory] = useState(0.5);
  const [lastTrials, setLastTrials] = useState(0);

  const submit = (e: FormEvent) => {
    e.preventDefault();
    try {
      const pPct = preset === 'custom' ? Number(customP.replace(',', '.')) : (PRESETS.find((x) => x.id === preset)?.p ?? 50);
      if (!Number.isFinite(pPct) || pPct < 0 || pPct > 100) throw new Error('Вероятность должна быть от 0% до 100%.');
      const n = Number(trials);
      if (!Number.isInteger(n) || n < 10 || n > 100000) throw new Error('Число испытаний: целое от 10 до 100 000.');
      const p = pPct / 100;
      const sim = simulateBernoulli(p, n);
      const diff = Math.abs(sim.frequency - p);
      setCumulative(sim.cumulative);
      setTheory(p);
      setLastTrials(n);
      const out: CalcOutput = {
        title: 'Симуляция случайного эксперимента', type: 'exact',
        probability: sim.frequency,
        headline: `В симуляции: ${sim.successes} успехов из ${n} (${formatPercent(sim.frequency)}), теория — ${formatPercent(p)}`,
        formula: 'Метод Монте-Карло: многократное случайное повторение + подсчёт частоты',
        inputs: [`Теоретическая вероятность одного испытания: ${formatPercent(p)}`, `Испытаний в симуляции: ${n}`, 'Генератор: Math.random (псевдослучайный, в вашем браузере)'],
        steps: [
          `Получено успехов: ${sim.successes} из ${n}.`,
          `Наблюдаемая частота: ${formatPercent(sim.frequency)}; отклонение от теории: ${formatPercent(diff)}.`,
          `Типичный масштаб случайного шума при таком n: σ ≈ ${formatPercent(Math.sqrt((p * (1 - p)) / n))}. Отклонение в этих пределах — норма, а не «сломанная монета».`,
          'Запустите ещё раз: результат немного изменится. С ростом n разброс частоты сужается как 1/√n.',
        ],
        assumptions: ['Испытания в симуляции независимы и честно случайны.'],
        limitations: ['Симуляция иллюстрирует теорию, а не доказывает её; один прогон — одна случайная реализация.'],
        warnings: n < 100 ? ['Меньше 100 испытаний: частота может сильно отличаться от теории просто от шума. Попробуйте 10 000.'] : [],
        summaryForHistory: `Монте-Карло p=${formatPercent(p)}, n=${n} → ${formatPercent(sim.frequency)}`,
      };
      setResult(out);
      setError(null);
      onSave(out);
    } catch (err) {
      setResult(null);
      setError(err instanceof Error ? err.message : 'Проверьте ввод.');
    }
  };

  return (
    <div>
      <p className="calc-intro">
        Симуляция не вычисляет формулу, а многократно «проживает» случайный эксперимент и считает частоту.
        Так видно закон больших чисел: на 20 бросках частота шумит, на 20 000 — прижимается к теории.
        Среднее число попыток до успеха при текущем p посчитает калькулятор «Хотя бы один успех»: ориентир 1/p = {formatNumber(1 / Math.max(0.0001, theory), 1)} при p = {formatPercent(theory)} (обновляется после запуска).
      </p>
      <form className="calc-form" onSubmit={submit} noValidate>
        <div className="field">
          <label htmlFor="sim-preset">Эксперимент</label>
          <select id="sim-preset" value={preset} onChange={(e) => setPreset(e.target.value)}>
            {PRESETS.map((x) => <option key={x.id} value={x.id}>{x.label}</option>)}
            <option value="custom">Своя вероятность…</option>
          </select>
        </div>
        {preset === 'custom' && (
          <div className="field">
            <label htmlFor="sim-p">Вероятность успеха, %</label>
            <input id="sim-p" value={customP} onChange={(e) => setCustomP(e.target.value)} inputMode="decimal" />
          </div>
        )}
        <div className="field">
          <label htmlFor="sim-n">Число испытаний</label>
          <input id="sim-n" value={trials} onChange={(e) => setTrials(e.target.value)} inputMode="numeric" />
          <span className="field-hint">От 10 до 100 000. Сравните 100 и 50 000 — разница шума видна на графике.</span>
        </div>
        {error && <p className="form-error" role="alert">{error}</p>}
        <button type="submit" className="btn btn-primary">Запустить симуляцию</button>
      </form>
      {result && (
        <>
          <ConvergenceChart cumulative={cumulative} p={theory} totalTrials={lastTrials} />
          <ResultCard result={result} />
        </>
      )}
    </div>
  );
}
