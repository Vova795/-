import { useMemo, useState } from 'react';
import { HANDBOOK } from '../lib/content';

export function Handbook({ query }: { query: string }) {
  const [openId, setOpenId] = useState<string | null>(HANDBOOK[0]?.id ?? null);
  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase();
    if (!q) return HANDBOOK;
    return HANDBOOK.filter((a) =>
      [a.title, a.short, a.example, a.mistake, ...a.body].join(' ').toLowerCase().includes(q),
    );
  }, [query]);

  if (filtered.length === 0) {
    return <p className="empty">В справочнике ничего не нашлось по запросу «{query}». Попробуйте слова: Байес, ожидание, независимые, интервал.</p>;
  }
  return (
    <div className="handbook">
      {filtered.map((a) => {
        const open = openId === a.id;
        return (
          <article key={a.id} className="book-card">
            <button
              type="button"
              className="book-head"
              aria-expanded={open}
              onClick={() => setOpenId(open ? null : a.id)}
            >
              <span><strong>{a.title}</strong><small>{a.short}</small></span>
              <span aria-hidden="true">{open ? '−' : '+'}</span>
            </button>
            {open && (
              <div className="book-body">
                {a.body.map((p, i) => <p key={i}>{p}</p>)}
                <p className="formula">{a.formula}</p>
                <p><strong>Пример:</strong> {a.example}</p>
                <p className="book-mistake"><strong>Частая ошибка:</strong> {a.mistake}</p>
              </div>
            )}
          </article>
        );
      })}
    </div>
  );
}
