import { formatPercent } from '../lib/probability';

/** Горизонтальная шкала вероятности 0–100% с отметкой значения (и интервала). */
export function ProbBar({ value, low, high }: { value: number; low?: number; high?: number }) {
  const pct = Math.max(0, Math.min(1, value)) * 100;
  return (
    <div className="probbar-wrap">
      <div
        className="probbar"
        role="img"
        aria-label={`Вероятность ${formatPercent(value)}${low !== undefined && high !== undefined ? `, интервал от ${formatPercent(low)} до ${formatPercent(high)}` : ''}`}
      >
        {low !== undefined && high !== undefined && (
          <div
            className="probbar-interval"
            style={{ left: `${low * 100}%`, width: `${Math.max(0.5, (high - low) * 100)}%` }}
          />
        )}
        <div className="probbar-fill" style={{ width: `${pct}%` }} />
        <div className="probbar-marker" style={{ left: `calc(${pct}% - 1px)` }} />
      </div>
      <div className="probbar-scale" aria-hidden="true">
        <span>0%</span><span>25%</span><span>50%</span><span>75%</span><span>100%</span>
      </div>
    </div>
  );
}

/** Столбчатая диаграмма биномиального распределения (SVG, без внешних библиотек). */
export function BinomialChart({ probs, highlightK }: { probs: number[]; highlightK: number }) {
  const max = Math.max(...probs, 0.0001);
  const W = 640;
  const H = 220;
  const padB = 28;
  const padT = 12;
  const n = probs.length - 1;
  const bw = W / probs.length;
  const step = n > 30 ? Math.ceil(n / 15) : 1;
  return (
    <figure className="chart">
      <svg viewBox={`0 0 ${W} ${H}`} className="chart-svg" role="img" aria-label={`Гистограмма биномиального распределения на ${n} испытаний. Выделено k равно ${highlightK}.`}>
        {probs.map((p, k) => {
          const h = (p / max) * (H - padB - padT);
          return (
            <g key={k}>
              <rect
                x={k * bw + 1}
                y={H - padB - h}
                width={Math.max(1, bw - 2)}
                height={h}
                rx={2}
                className={k === highlightK ? 'bar bar-hot' : 'bar'}
              >
                <title>{`k=${k}: ${formatPercent(p)}`}</title>
              </rect>
              {(k % step === 0 || k === highlightK) && (
                <text x={k * bw + bw / 2} y={H - 8} textAnchor="middle" className="chart-label">
                  {k}
                </text>
              )}
            </g>
          );
        })}
        <line x1={0} y1={H - padB} x2={W} y2={H - padB} className="chart-axis" />
      </svg>
      <figcaption>
        Столбцы — P(X = k). Выделено k = {highlightK}: {formatPercent(probs[highlightK] ?? 0)}. Подписи по оси — число успехов.
      </figcaption>
    </figure>
  );
}

/** График сходимости наблюдаемой частоты к теоретическому p в симуляции. */
export function ConvergenceChart({ cumulative, p, totalTrials }: { cumulative: number[]; p: number; totalTrials: number }) {
  if (cumulative.length === 0) return null;
  const W = 640;
  const H = 200;
  const pad = 30;
  const vals = [...cumulative, p];
  let min = Math.min(...vals);
  let max = Math.max(...vals);
  if (max - min < 0.1) { min = Math.max(0, p - 0.08); max = Math.min(1, p + 0.08); }
  min = Math.max(0, min - 0.02); max = Math.min(1, max + 0.02);
  const sx = (i: number) => pad + (i / Math.max(1, cumulative.length - 1)) * (W - pad - 8);
  const sy = (v: number) => H - pad - ((v - min) / (max - min)) * (H - pad - 12);
  const points = cumulative.map((v, i) => `${sx(i).toFixed(1)},${sy(v).toFixed(1)}`).join(' ');
  return (
    <figure className="chart">
      <svg viewBox={`0 0 ${W} ${H}`} className="chart-svg" role="img" aria-label={`График сходимости частоты к теоретической вероятности ${formatPercent(p)} за ${totalTrials} испытаний`}>
        <line x1={pad} y1={sy(p)} x2={W - 8} y2={sy(p)} className="chart-theory" />
        <polyline points={points} className="chart-line" fill="none" />
        <text x={pad + 4} y={Math.max(12, sy(p) - 6)} className="chart-note">теория: {formatPercent(p)}</text>
        <text x={pad} y={H - 8} className="chart-label">1</text>
        <text x={W - 60} y={H - 8} className="chart-label">{totalTrials} исп.</text>
        <text x={4} y={sy(max - 0.02)} className="chart-label">{formatPercent(max)}</text>
        <text x={4} y={sy(min + 0.001)} className="chart-label">{formatPercent(min)}</text>
      </svg>
      <figcaption>Синяя линия — наблюдаемая доля успехов по мере роста числа испытаний. Пунктир — истинная вероятность. Чем больше испытаний, тем ближе частота к теории, но без «компенсации» прошлого.</figcaption>
    </figure>
  );
}
