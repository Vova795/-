import { useState, type FormEvent, type ReactNode } from 'react';
import {
  basicProbability, independentAnd, independentOr, dependentAnd,
  allFavorableWithoutReplacement, bayes, binomialPMF, binomialCDF, binomialAtLeast,
  binomialDistribution, atLeastOne, expectedTrialsUntilSuccess, expectedValue,
  frequencyEstimate, formatPercent, formatNumber,
} from '../lib/probability';
import { CALCULATORS } from '../lib/content';
import { ResultCard, type CalcOutput } from './ResultCard';
import { BinomialChart, ProbBar } from './Charts';

// ── helpers ──────────────────────────────────────────────────────────────────

function parseNum(v: string): number {
  return Number(v.trim().replace(/\s/g, '').replace(',', '.'));
}
function parsePct(v: string): number {
  const n = parseNum(v);
  if (!Number.isFinite(n)) throw new Error('Введите число в процентах, например 25 или 12,5.');
  return n / 100;
}
function parseProbList(v: string): number[] {
  const parts = v.split(/[,;]+/).map((s) => s.trim()).filter(Boolean);
  if (parts.length === 0) throw new Error('Укажите хотя бы одну вероятность в процентах через запятую.');
  return parts.map((s) => {
    const n = Number(s.replace(',', '.'));
    if (!Number.isFinite(n) || n < 0 || n > 100) throw new Error(`«${s}» — не вероятность в процентах от 0 до 100.`);
    return n / 100;
  });
}

function Field(props: { label: string; value: string; onChange: (v: string) => void; hint?: string; inputMode?: 'decimal' | 'numeric' | 'text'; placeholder?: string }) {
  const id = `f-${props.label.replace(/\W+/g, '-').slice(0, 40)}`;
  return (
    <div className="field">
      <label htmlFor={id}>{props.label}</label>
      <input id={id} value={props.value} onChange={(e) => props.onChange(e.target.value)} inputMode={props.inputMode ?? 'decimal'} placeholder={props.placeholder} />
      {props.hint && <span className="field-hint">{props.hint}</span>}
    </div>
  );
}

function Shell(props: { onSubmit: (e: FormEvent) => void; error: string | null; children: ReactNode; submitLabel?: string }) {
  return (
    <form className="calc-form" onSubmit={props.onSubmit} noValidate>
      {props.children}
      {props.error && <p className="form-error" role="alert">{props.error}</p>}
      <button type="submit" className="btn btn-primary">{props.submitLabel ?? 'Рассчитать'}</button>
    </form>
  );
}

type Done = (o: CalcOutput) => void;
function useCalc(done: Done) {
  const [error, setError] = useState<string | null>(null);
  const [result, setResult] = useState<CalcOutput | null>(null);
  const run = (fn: () => CalcOutput) => (e: FormEvent) => {
    e.preventDefault();
    try {
      setError(null);
      const out = fn();
      setResult(out);
      done(out);
    } catch (err) {
      setResult(null);
      setError(err instanceof Error ? err.message : 'Проверьте введённые данные.');
    }
  };
  return { error, result, run };
}

// ── 1. Базовая вероятность ───────────────────────────────────────────────────

function BasicCalc({ done }: { done: Done }) {
  const { error, result, run } = useCalc(done);
  const [mode, setMode] = useState('single');
  const [fav, setFav] = useState('1');
  const [total, setTotal] = useState('6');
  const [list, setList] = useState('50, 50');
  const [pA, setPA] = useState('50');
  const [pBgA, setPBgA] = useState('40');
  const [urnTotal, setUrnTotal] = useState('10');
  const [urnFav, setUrnFav] = useState('4');
  const [urnDraws, setUrnDraws] = useState('2');

  const compute = (): CalcOutput => {
    if (mode === 'single') {
      const f = parseNum(fav); const t = parseNum(total);
      const p = basicProbability(f, t);
      return {
        title: 'Базовая вероятность', type: 'exact', probability: p,
        headline: `${formatPercent(p)} — ${f} благоприятных из ${t}`,
        formula: `P = m / n = ${f} / ${t}`,
        inputs: [`Благоприятных исходов m = ${f}`, `Всех исходов n = ${t}`],
        steps: [`Делим благоприятные исходы на все: ${f} / ${t} = ${formatPercent(p)}.`],
        assumptions: ['Все исходы равновозможны.', 'Выбор действительно случаен.'],
        limitations: ['Если исходы не равновозможны (подтасованный кубик, неслучайный выбор), формула неприменима.'],
        warnings: [],
        summaryForHistory: `${f} из ${t}`,
      };
    }
    if (mode === 'and' || mode === 'or') {
      const ps = parseProbList(list);
      const p = mode === 'and' ? independentAnd(ps) : independentOr(ps);
      const label = mode === 'and' ? 'И (все события вместе)' : 'ИЛИ (хотя бы одно из событий)';
      return {
        title: `Независимые события: ${label}`, type: 'exact', probability: p,
        headline: `${formatPercent(p)} — ${label.toLowerCase()}`,
        formula: mode === 'and' ? `P = ${ps.map((x) => formatPercent(x)).join(' × ')}` : `P = 1 − ${ps.map((x) => `(1 − ${formatPercent(x)})`).join(' × ')}`,
        inputs: ps.map((x, i) => `Событие ${i + 1}: ${formatPercent(x)}`),
        steps: mode === 'and'
          ? ['Для независимых событий вероятности совместного наступления перемножаются.', `Итог: ${formatPercent(p)}.`]
          : ['Считаем через противоположное: ни одно событие не наступает, затем вычитаем из 100%.', `Итог: ${formatPercent(p)}.`],
        assumptions: ['События независимы: исход одного не меняет шансы других.'],
        limitations: ['Самая частая ошибка — применять умножение к зависимым событиям (например, вытягивание без возвращения).'],
        warnings: [],
        summaryForHistory: `${label}: ${ps.map((x) => formatPercent(x)).join(', ')}`,
      };
    }
    if (mode === 'dependent') {
      const a = parsePct(pA); const b = parsePct(pBgA);
      const p = dependentAnd(a, b);
      return {
        title: 'Зависимые события: P(A и B)', type: 'exact', probability: p,
        headline: `${formatPercent(p)} — сначала A, затем B при условии A`,
        formula: `P(A∩B) = P(A) · P(B|A) = ${formatPercent(a)} × ${formatPercent(b)}`,
        inputs: [`P(A) = ${formatPercent(a)}`, `P(B | A уже произошло) = ${formatPercent(b)}`],
        steps: ['Берём шанс первого события.', 'Умножаем на шанс второго именно в ситуации, когда первое уже произошло.', `Итог: ${formatPercent(p)}.`],
        assumptions: ['P(B|A) — вероятность B именно при наступившем A, а не «вообще».'],
        limitations: ['Если условная вероятность неизвестна, её нельзя заменять обычной P(B) — это уже предположение о независимости.'],
        warnings: [],
        summaryForHistory: `P(A)=${formatPercent(a)}, P(B|A)=${formatPercent(b)}`,
      };
    }
    // urn
    const t = parseNum(urnTotal); const f = parseNum(urnFav); const d = parseNum(urnDraws);
    const p = allFavorableWithoutReplacement(t, f, d);
    const parts: string[] = [];
    for (let i = 0; i < d; i++) parts.push(`${f - i}/${t - i}`);
    return {
      title: 'Выбор без возвращения: все вытащенные — нужные', type: 'exact', probability: p,
      headline: `${formatPercent(p)} — все ${d} вытащенных окажутся благоприятными`,
      formula: `P = ${parts.join(' × ')}`,
      inputs: [`Всего объектов: ${t}`, `Благоприятных: ${f}`, `Вытаскиваем подряд без возвращения: ${d}`],
      steps: ['После каждого вытаскивания состав меняется, поэтому доли пересчитываются на каждом шаге.', `Перемножаем шаги: итог ${formatPercent(p)}.`],
      assumptions: ['Объекты перемешаны, вытаскивание случайно, вытащенное не возвращают.'],
      limitations: ['Если объекты возвращают обратно, используйте независимые события — шансы не меняются.'],
      warnings: [],
      summaryForHistory: `${d} из урны ${f}/${t} без возвращения`,
    };
  };

  return (
    <div>
      <div className="field">
        <label htmlFor="basic-mode">Что считаем?</label>
        <select id="basic-mode" value={mode} onChange={(e) => setMode(e.target.value)}>
          <option value="single">Одно событие: благоприятные / все исходы</option>
          <option value="and">Независимые: И (все вместе)</option>
          <option value="or">Независимые: ИЛИ (хотя бы одно)</option>
          <option value="dependent">Зависимые: A, а затем B при условии A</option>
          <option value="urn">Без возвращения: все вытащенные — благоприятные (урна)</option>
        </select>
      </div>
      <Shell onSubmit={run(compute)} error={error}>
        {mode === 'single' && <>
          <Field label="Благоприятных исходов" value={fav} onChange={setFav} inputMode="numeric" />
          <Field label="Всего равновозможных исходов" value={total} onChange={setTotal} inputMode="numeric" />
        </>}
        {(mode === 'and' || mode === 'or') && <Field label="Вероятности событий в %, через запятую" value={list} onChange={setList} hint="Например: 50, 50 — два события по 50%" />}
        {mode === 'dependent' && <>
          <Field label="P(A), %" value={pA} onChange={setPA} />
          <Field label="P(B | A), % — шанс B, если A уже произошло" value={pBgA} onChange={setPBgA} />
        </>}
        {mode === 'urn' && <>
          <Field label="Всего объектов" value={urnTotal} onChange={setUrnTotal} inputMode="numeric" />
          <Field label="Из них благоприятных" value={urnFav} onChange={setUrnFav} inputMode="numeric" />
          <Field label="Вытаскиваем подряд" value={urnDraws} onChange={setUrnDraws} inputMode="numeric" />
        </>}
      </Shell>
      {result && <ResultCard result={result} />}
    </div>
  );
}

// ── 2. Байес ─────────────────────────────────────────────────────────────────

function BayesCalc({ done }: { done: Done }) {
  const { error, result, run } = useCalc(done);
  const [prior, setPrior] = useState('1');
  const [lh, setLh] = useState('99');
  const [lhNot, setLhNot] = useState('5');
  const compute = (): CalcOutput => {
    const pr = parsePct(prior); const a = parsePct(lh); const b = parsePct(lhNot);
    const r = bayes(pr, a, b);
    return {
      title: 'Формула Байеса: вероятность после свидетельства', type: 'exact', probability: r.posterior,
      headline: `Было ${formatPercent(pr)} → стало ${formatPercent(r.posterior)}`,
      formula: 'P(H|E) = P(E|H)·P(H) / [P(E|H)·P(H) + P(E|¬H)·P(¬H)]',
      inputs: [`P(H) до свидетельства: ${formatPercent(pr)}`, `P(E|H): ${formatPercent(a)}`, `P(E|¬H): ${formatPercent(b)}`],
      steps: [
        `Свидетельство при верной гипотезе, взвешенное prior: ${formatPercent(a)} × ${formatPercent(pr)} = ${formatPercent(r.numerator)}.`,
        `Полная вероятность свидетельства P(E) = ${formatPercent(r.marginal)} (включая случаи без гипотезы).`,
        `Делим: ${formatPercent(r.posterior)}.`,
      ],
      assumptions: ['Гипотез ровно две: H и «не H».', 'Все три исходные вероятности относятся к той же популяции/ситуации.'],
      limitations: ['Результат наследует ошибки исходных оценок, особенно базовой частоты.'],
      warnings: pr < 0.05 ? ['Гипотеза редкая: даже «точное» свидетельство часто срабатывает вхолостую. Не удивляйтесь итогу заметно ниже P(E|H).'] : [],
      extra: (
        <div className="compare-bars">
          <div><span>До: {formatPercent(pr)}</span><ProbBar value={pr} /></div>
          <div><span>После: {formatPercent(r.posterior)}</span><ProbBar value={r.posterior} /></div>
        </div>
      ),
      summaryForHistory: `prior ${formatPercent(pr)}, E|H ${formatPercent(a)}, E|¬H ${formatPercent(b)}`,
    };
  };
  return (
    <div>
      <p className="calc-intro">Пример по умолчанию — медицинский тест при редкой болезни. Он показывает, почему положительный результат «точного на 99%» теста не означает болезнь на 99%.</p>
      <Shell onSubmit={run(compute)} error={error}>
        <Field label="P(H), % — вероятность гипотезы ДО свидетельства (базовая частота)" value={prior} onChange={setPrior} />
        <Field label="P(E|H), % — шанс такого свидетельства, если гипотеза верна" value={lh} onChange={setLh} />
        <Field label="P(E|¬H), % — шанс такого же свидетельства, если гипотезы нет" value={lhNot} onChange={setLhNot} />
      </Shell>
      {result && <ResultCard result={result} />}
    </div>
  );
}

// ── 3. Биномиальное ──────────────────────────────────────────────────────────

function BinomialCalc({ done }: { done: Done }) {
  const { error, result, run } = useCalc(done);
  const [n, setN] = useState('10');
  const [k, setK] = useState('7');
  const [p, setP] = useState('50');
  const compute = (): CalcOutput => {
    const nn = parseNum(n); const kk = parseNum(k); const pp = parsePct(p);
    const exact = binomialPMF(nn, kk, pp);
    const le = binomialCDF(nn, kk, pp);
    const ge = binomialAtLeast(nn, kk, pp);
    const dist = binomialDistribution(nn, pp);
    return {
      title: `Биномиальное: успехи в ${nn} испытаниях`, type: 'exact', probability: exact,
      headline: `Ровно ${kk} успехов: ${formatPercent(exact)} · не более ${kk}: ${formatPercent(le)} · не менее ${kk}: ${formatPercent(ge)}`,
      formula: `P(X=k) = C(n,k)·pᵏ·(1−p)ⁿ⁻ᵏ при n=${nn}, k=${kk}, p=${formatPercent(pp)}`,
      inputs: [`Испытаний n = ${nn}`, `Успехов k = ${kk}`, `Шанс успеха p = ${formatPercent(pp)}`],
      steps: [
        `Среднее число успехов: n·p = ${formatNumber(dist.mean, 2)}, стандартное отклонение σ = ${formatNumber(dist.sd, 2)}.`,
        `Ровно ${kk}: ${formatPercent(exact)}. Не более ${kk}: ${formatPercent(le)}. Не менее ${kk}: ${formatPercent(ge)}.`,
        'На графике видно всё распределение: «ровно среднее» — далеко не единственный и не всегда самый вероятный сценарий по сумме с соседями.',
      ],
      assumptions: ['Число испытаний фиксировано, каждое с двумя исходами.', 'p одинаков, испытания независимы.'],
      limitations: ['Если шансы меняются по ходу серии или попытки связаны, нужна другая модель.'],
      warnings: nn < 5 ? ['Очень мало испытаний: распределение крайне шумное, выводы по нему шаткие.'] : [],
      extra: <BinomialChart probs={dist.probs} highlightK={kk} />,
      summaryForHistory: `n=${nn}, k=${kk}, p=${formatPercent(pp)}`,
    };
  };
  return (
    <div>
      <Shell onSubmit={run(compute)} error={error}>
        <Field label="Число испытаний n" value={n} onChange={setN} inputMode="numeric" />
        <Field label="Число успехов k" value={k} onChange={setK} inputMode="numeric" />
        <Field label="Вероятность успеха в одном испытании, %" value={p} onChange={setP} />
      </Shell>
      {result && <ResultCard result={result} />}
    </div>
  );
}

// ── 4. Хотя бы один ──────────────────────────────────────────────────────────

function AtLeastCalc({ done }: { done: Done }) {
  const { error, result, run } = useCalc(done);
  const [n, setN] = useState('20');
  const [p, setP] = useState('5');
  const compute = (): CalcOutput => {
    const nn = parseNum(n); const pp = parsePct(p);
    const prob = atLeastOne(nn, pp);
    const wait = expectedTrialsUntilSuccess(pp);
    return {
      title: 'Хотя бы один успех за серию', type: 'exact', probability: prob,
      headline: `${formatPercent(prob)} — хотя бы один раз за ${nn} попыток`,
      formula: `P = 1 − (1 − p)ⁿ = 1 − (1 − ${formatPercent(pp)})^${nn}`,
      inputs: [`Попыток n = ${nn}`, `Шанс одной попытки p = ${formatPercent(pp)}`],
      steps: [
        `Шанс, что не повезёт ни разу: (1 − p)ⁿ = ${formatPercent((1 - pp) ** nn)}.`,
        `Вычитаем из 100%: ${formatPercent(prob)}.`,
        `В среднем первого успеха ждут ${wait === Infinity ? 'бесконечно (p=0)' : `≈ ${formatNumber(wait, 1)} попыток`} — это среднее, а не обещание к сроку.`,
      ],
      assumptions: ['Попытки независимы, p не меняется.'],
      limitations: ['«В среднем через 1/p попыток» не значит «гарантированно за 1/p попыток»: к этому моменту шанс хотя бы одного успеха — только около 63% при малых p.'],
      warnings: [],
      summaryForHistory: `n=${nn}, p=${formatPercent(pp)}`,
    };
  };
  return (
    <div>
      <Shell onSubmit={run(compute)} error={error}>
        <Field label="Число попыток n" value={n} onChange={setN} inputMode="numeric" />
        <Field label="Вероятность успеха в одной попытке, %" value={p} onChange={setP} />
      </Shell>
      {result && <ResultCard result={result} />}
    </div>
  );
}

// ── 5. Матожидание ───────────────────────────────────────────────────────────

function ExpectedCalc({ done }: { done: Done }) {
  const { error, result, run } = useCalc(done);
  const [rows, setRows] = useState<{ value: string; prob: string }[]>(
    [1, 2, 3, 4, 5, 6].map((v) => ({ value: String(v), prob: (100 / 6).toFixed(2) })),
  );
  const compute = (): CalcOutput => {
    const outcomes = rows.map((r) => ({ value: parseNum(r.value), probability: parsePct(r.prob) }));
    const r = expectedValue(outcomes);
    return {
      title: 'Математическое ожидание', type: 'exact', probability: null,
      headline: `Среднее при многих повторениях: ${formatNumber(r.expected, 3)} (стандартное отклонение ${formatNumber(r.sd, 3)})`,
      formula: 'E = Σ значение·вероятность; σ = √[Σ p·(значение − E)²]',
      inputs: rows.map((x, i) => `Исход ${i + 1}: значение ${x.value} с вероятностью ${x.prob}%`),
      steps: [
        `Сумма вероятностей проверена: ${formatPercent(r.sumProbabilities)} (нужно 100%).`,
        `E = ${formatNumber(r.expected, 4)}. Дисперсия = ${formatNumber(r.variance, 4)}, σ = ${formatNumber(r.sd, 4)}.`,
        'E — это среднее за очень большое число повторений, а не прогноз одного раза.',
      ],
      assumptions: ['Перечислены ВСЕ возможные исходы, вероятности суммируются в 100%.'],
      limitations: ['При малом числе повторений фактическое среднее может сильно отличаться — смотрите на σ.'],
      warnings: [],
      extra: (
        <div className="ev-big">
          <div><span>Ожидание E</span><strong>{formatNumber(r.expected, 3)}</strong></div>
          <div><span>Разброс σ</span><strong>{formatNumber(r.sd, 3)}</strong></div>
        </div>
      ),
      summaryForHistory: `E=${formatNumber(r.expected, 3)}, σ=${formatNumber(r.sd, 3)}, исходов: ${rows.length}`,
    };
  };
  const setRow = (i: number, key: 'value' | 'prob', v: string) =>
    setRows((rs) => rs.map((r, j) => (j === i ? { ...r, [key]: v } : r)));
  return (
    <div>
      <p className="calc-intro">Предзаполнен честный кубик: ожидание 3,5 — хотя такое значение никогда не выпадает. Измените значения и вероятности под свою задачу (проценты, сумма строго 100%).</p>
      <Shell onSubmit={run(compute)} error={error} submitLabel="Рассчитать ожидание">
        <div className="ev-rows">
          {rows.map((r, i) => (
            <div className="ev-row" key={i}>
              <Field label={`Значение исхода ${i + 1}`} value={r.value} onChange={(v) => setRow(i, 'value', v)} />
              <Field label="Вероятность, %" value={r.prob} onChange={(v) => setRow(i, 'prob', v)} />
              <button type="button" className="btn btn-ghost" disabled={rows.length <= 1} onClick={() => setRows((rs) => rs.filter((_, j) => j !== i))} aria-label={`Удалить исход ${i + 1}`}>Удалить</button>
            </div>
          ))}
        </div>
        <button type="button" className="btn btn-ghost" onClick={() => setRows((rs) => [...rs, { value: '0', prob: '0' }])}>+ Добавить исход</button>
      </Shell>
      {result && <ResultCard result={result} />}
    </div>
  );
}

// ── 6. Частота по данным ─────────────────────────────────────────────────────

function FrequencyCalc({ done }: { done: Done }) {
  const { error, result, run } = useCalc(done);
  const [succ, setSucc] = useState('7');
  const [trials, setTrials] = useState('10');
  const compute = (): CalcOutput => {
    const s = parseNum(succ); const t = parseNum(trials);
    const r = frequencyEstimate(s, t);
    return {
      title: 'Оценка вероятности по данным', type: 'statistical', probability: r.pHat,
      headline: `${formatPercent(r.pHat)} по наблюдениям; истинное значение правдоподобно в пределах ${formatPercent(r.low)}–${formatPercent(r.high)}`,
      formula: `p̂ = ${s} / ${t}; 95% интервал Вильсона`,
      inputs: [`Успехов: ${s}`, `Всего наблюдений: ${t}`],
      steps: [
        `Точечная оценка: ${s}/${t} = ${formatPercent(r.pHat)}.`,
        `Стандартная ошибка ≈ ${formatPercent(r.standardError)} — масштаб случайного шума при таком объёме данных.`,
        `Интервал Вильсона (95%): ${formatPercent(r.low)} – ${formatPercent(r.high)}. Именно его, а не одно число, честно показывать другим.`,
      ],
      assumptions: ['Наблюдения независимы, условия стабильны.', 'Данные собраны без смещения (не только удачные или только запомнившиеся случаи).'],
      limitations: ['Прошлая частота предсказывает будущее, только если процесс не изменился.', 'Корреляция наблюдений (сериями, от одного источника) делает интервал оптимистично узким.'],
      warnings: r.warnings,
      interval: { low: r.low, high: r.high },
      summaryForHistory: `${s} из ${t}`,
    };
  };
  return (
    <div>
      <p className="calc-intro">Введите, сколько раз событие произошло и сколько всего было наблюдений. Покажем не только долю, но и интервал неопределённости — при малых числах он важнее самой доли.</p>
      <Shell onSubmit={run(compute)} error={error}>
        <Field label="Сколько раз событие произошло (успехов)" value={succ} onChange={setSucc} inputMode="numeric" />
        <Field label="Сколько всего было наблюдений" value={trials} onChange={setTrials} inputMode="numeric" />
      </Shell>
      {result && <ResultCard result={result} />}
    </div>
  );
}

// ── Обёртка со списком калькуляторов ─────────────────────────────────────────

export function Calculators({ active, onSelect, onSave }: {
  active: string;
  onSelect: (id: string) => void;
  onSave: (o: CalcOutput) => void;
}) {
  return (
    <div className="calc-layout">
      <nav className="calc-nav" aria-label="Список калькуляторов">
        {CALCULATORS.map((c) => (
          <button key={c.id} type="button" className={`calc-nav-item${active === c.id ? ' active' : ''}`} onClick={() => onSelect(c.id)} aria-pressed={active === c.id}>
            <strong>{c.title}</strong>
            <span>{c.short}</span>
            <span className={`badge badge-${c.type}`}>{c.type === 'exact' ? 'точная' : 'по данным'}</span>
          </button>
        ))}
      </nav>
      <div className="calc-panel">
        {active === 'basic' && <BasicCalc done={onSave} />}
        {active === 'bayes' && <BayesCalc done={onSave} />}
        {active === 'binomial' && <BinomialCalc done={onSave} />}
        {active === 'atleast' && <AtLeastCalc done={onSave} />}
        {active === 'expected' && <ExpectedCalc done={onSave} />}
        {active === 'frequency' && <FrequencyCalc done={onSave} />}
      </div>
    </div>
  );
}
