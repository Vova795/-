import type { ReactNode } from 'react';
import { ESTIMATE_LABELS, formatPercent, interpretProbability, oneInN, type EstimateType } from '../lib/probability';
import { ProbBar } from './Charts';

export interface CalcOutput {
  title: string;
  type: EstimateType;
  probability: number | null;
  headline: string;
  formula: string;
  inputs: string[];
  steps: string[];
  assumptions: string[];
  limitations: string[];
  warnings: string[];
  extra?: ReactNode;
  interval?: { low: number; high: number };
  summaryForHistory: string;
}

export function ResultCard({ result }: { result: CalcOutput }) {
  const p = result.probability;
  return (
    <section className="result-card" aria-live="polite" aria-label={`Результат: ${result.title}`}>
      <div className="result-head">
        <h3>{result.title}</h3>
        <span className={`badge badge-${result.type}`}>{ESTIMATE_LABELS[result.type]}</span>
      </div>

      {p !== null ? (
        <>
          <div className="result-percent">
            <span className="result-big">{formatPercent(p)}</span>
            {result.interval && (
              <span className="result-interval">95% интервал: {formatPercent(result.interval.low)} – {formatPercent(result.interval.high)}</span>
            )}
            {oneInN(p) && <span className="result-onein">{oneInN(p)}</span>}
          </div>
          <ProbBar value={p} low={result.interval?.low} high={result.interval?.high} />
          <p className="result-interpret">{interpretProbability(p)}</p>
        </>
      ) : (
        <p className="result-headline">{result.headline}</p>
      )}
      {p !== null && <p className="result-headline-sub">{result.headline}</p>}

      {result.extra}

      <div className="result-grid">
        <div>
          <h4>Откуда число: формула / метод</h4>
          <p className="formula">{result.formula}</p>
          {result.steps.length > 0 && (
            <ol className="steps">
              {result.steps.map((s, i) => <li key={i}>{s}</li>)}
            </ol>
          )}
        </div>
        <div>
          <h4>Исходные данные</h4>
          {result.inputs.length > 0 ? (
            <ul className="plain-list">{result.inputs.map((s, i) => <li key={i}>{s}</li>)}</ul>
          ) : <p>—</p>}
        </div>
        <div>
          <h4>Допущения</h4>
          {result.assumptions.length > 0 ? (
            <ul className="plain-list">{result.assumptions.map((s, i) => <li key={i}>{s}</li>)}</ul>
          ) : <p>—</p>}
        </div>
        <div>
          <h4>Ограничения</h4>
          {result.limitations.length > 0 ? (
            <ul className="plain-list">{result.limitations.map((s, i) => <li key={i}>{s}</li>)}</ul>
          ) : <p>—</p>}
        </div>
      </div>

      {result.warnings.length > 0 && (
        <div className="warnings" role="note">
          <strong>Обратите внимание:</strong>
          <ul>{result.warnings.map((w, i) => <li key={i}>{w}</li>)}</ul>
        </div>
      )}
      <p className="history-note">Расчёт автоматически сохранён в историю на этом устройстве (см. вкладку «История»). На сервер ничего не отправляется.</p>
    </section>
  );
}
