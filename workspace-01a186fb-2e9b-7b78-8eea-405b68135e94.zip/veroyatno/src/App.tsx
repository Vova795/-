import { useEffect, useMemo, useState, type FormEvent } from 'react';
import './index.css';
import { analyzeQuery, EXAMPLE_QUERIES, type Analysis } from './lib/analyze';
import { CALCULATORS, HANDBOOK } from './lib/content';
import { loadHistory, saveHistory, makeEntry, type HistoryEntry } from './lib/history';
import { ESTIMATE_LABELS, formatPercent, frequencyEstimate } from './lib/probability';
import { Calculators } from './components/Calculators';
import { Simulator } from './components/Simulator';
import { Handbook } from './components/Handbook';
import { ResultCard, type CalcOutput } from './components/ResultCard';

type Tab = 'home' | 'calc' | 'sim' | 'book' | 'history';

const TABS: { id: Tab; label: string }[] = [
  { id: 'home', label: 'Оценить' },
  { id: 'calc', label: 'Калькуляторы' },
  { id: 'sim', label: 'Симулятор' },
  { id: 'book', label: 'Справочник' },
  { id: 'history', label: 'История' },
];

function analysisToOutput(a: Analysis, query: string): CalcOutput {
  return {
    title: a.title,
    type: a.type,
    probability: a.probability,
    headline: a.headline,
    formula: a.formula,
    inputs: a.inputs.length ? a.inputs : [`Запрос: «${query}»`],
    steps: a.steps,
    assumptions: a.assumptions,
    limitations: a.limitations,
    warnings: a.warnings,
    interval: a.interval,
    summaryForHistory: query,
  };
}

/** Честная субъективная оценка: с диапазоном, основаниями и ярлыком «субъективная». */
function SubjectiveEstimator({ onSave }: { onSave: (o: CalcOutput) => void }) {
  const [event, setEvent] = useState('');
  const [baseSucc, setBaseSucc] = useState('');
  const [baseTrials, setBaseTrials] = useState('');
  const [estimate, setEstimate] = useState(50);
  const [confidence, setConfidence] = useState('medium');
  const [factors, setFactors] = useState('');
  const [result, setResult] = useState<CalcOutput | null>(null);
  const [error, setError] = useState<string | null>(null);

  const submit = (e: FormEvent) => {
    e.preventDefault();
    try {
      const width = confidence === 'low' ? 0.2 : confidence === 'high' ? 0.05 : 0.1;
      let centre = estimate / 100;
      const inputs: string[] = [`Событие: ${event.trim() || '(не указано)'}`];
      let baseNote = 'Базовая частота не указана — оценка опирается только на ваше суждение.';
      if (baseSucc.trim() !== '' || baseTrials.trim() !== '') {
        const s = Number(baseSucc); const t = Number(baseTrials);
        const f = frequencyEstimate(s, t);
        centre = (centre + f.pHat) / 2;
        baseNote = `Базовая частота по вашим данным: ${s} из ${t} = ${formatPercent(f.pHat)} (95% интервал ${formatPercent(f.low)}–${formatPercent(f.high)}). Центр диапазона ниже — среднее между ней и вашей оценкой; сверьтесь, нет ли причин от неё отходить.`;
        inputs.push(`Похожие случаи в прошлом: ${s} успехов из ${t}`);
      }
      inputs.push(`Ваша первичная оценка: ${estimate}%`, `Уверенность: ${confidence === 'low' ? 'низкая (±20 п.п.)' : confidence === 'high' ? 'высокая (±5 п.п.)' : 'средняя (±10 п.п.)'}`);
      if (factors.trim()) inputs.push(`Факторы «за/против»: ${factors.trim()}`);
      const low = Math.max(0, centre - width);
      const high = Math.min(1, centre + width);
      const out: CalcOutput = {
        title: 'Субъективная оценка (не измерение)', type: 'subjective', probability: centre,
        headline: `Оценка ${formatPercent(centre)}, честный диапазон: ${formatPercent(low)}–${formatPercent(high)}`,
        formula: 'Старт от базовой частоты + явное суждение; ширина диапазона зависит от заявленной уверенности',
        inputs,
        steps: [baseNote, 'Это мнение, оформленное числом. Его ценность — в перечисленных основаниях, а не в десятичных знаках.'],
        assumptions: factors.trim() ? [`Перечисленные вами факторы действительно влияют: ${factors.trim()}`] : ['Вы не перечислили факторы — оценка ничем не подкреплена, кроме интуиции.'],
        limitations: ['Субъективные оценки людей обычно слишком самоуверенны: реальные диапазоны шире ощущаемых.', 'Проверяйте калибровку постфактум: из ваших «70%» должно сбываться примерно 7 из 10.'],
        warnings: ['Не сообщайте эту оценку другим как «посчитанную вероятность» — это субъективный прогноз.'],
        interval: { low, high },
        summaryForHistory: event.trim() || 'Субъективная оценка',
      };
      setResult(out);
      setError(null);
      onSave(out);
    } catch (err) {
      setResult(null);
      setError(err instanceof Error ? err.message : 'Проверьте данные базовой частоты (успехи не больше испытаний).');
    }
  };

  return (
    <section className="panel" aria-labelledby="subj-h">
      <h2 id="subj-h">Событие реального мира? Соберите честную субъективную оценку</h2>
      <p className="muted">Для таких событий нет формулы. Вместо выдуманной точности: базовая частота похожих случаев (если есть), ваша оценка и диапазон неопределённости. Результат будет помечен как субъективный.</p>
      <form className="calc-form" onSubmit={submit} noValidate>
        <div className="field">
          <label htmlFor="subj-event">Событие</label>
          <input id="subj-event" value={event} onChange={(e) => setEvent(e.target.value)} placeholder="Например: успею сдать проект к пятнице" />
        </div>
        <div className="form-row">
          <div className="field">
            <label htmlFor="subj-s">Похожие случаи: успехов было</label>
            <input id="subj-s" value={baseSucc} onChange={(e) => setBaseSucc(e.target.value)} inputMode="numeric" placeholder="необязательно" />
          </div>
          <div className="field">
            <label htmlFor="subj-t">а всего таких случаев</label>
            <input id="subj-t" value={baseTrials} onChange={(e) => setBaseTrials(e.target.value)} inputMode="numeric" placeholder="необязательно" />
          </div>
        </div>
        <div className="field">
          <label htmlFor="subj-est">Ваша оценка: {estimate}%</label>
          <input id="subj-est" type="range" min={0} max={100} value={estimate} onChange={(e) => setEstimate(Number(e.target.value))} />
        </div>
        <div className="field">
          <label htmlFor="subj-conf">Насколько вы уверены?</label>
          <select id="subj-conf" value={confidence} onChange={(e) => setConfidence(e.target.value)}>
            <option value="low">Слабо — широкий диапазон ±20 п.п.</option>
            <option value="medium">Средне — диапазон ±10 п.п.</option>
            <option value="high">Сильно (есть данные/опыт) — ±5 п.п.</option>
          </select>
        </div>
        <div className="field">
          <label htmlFor="subj-factors">Какие факты за и против? (основания оценки)</label>
          <textarea id="subj-factors" value={factors} onChange={(e) => setFactors(e.target.value)} rows={2} placeholder="Например: два из трёх этапов готовы; но зависим от подрядчика" />
        </div>
        {error && <p className="form-error" role="alert">{error}</p>}
        <button type="submit" className="btn btn-primary">Собрать оценку</button>
      </form>
      {result && <ResultCard result={result} />}
    </section>
  );
}

export default function App() {
  const [tab, setTab] = useState<Tab>('home');
  const [calcId, setCalcId] = useState('basic');
  const [query, setQuery] = useState('');
  const [search, setSearch] = useState('');
  const [analysis, setAnalysis] = useState<Analysis | null>(null);
  const [lastQuery, setLastQuery] = useState('');
  const [history, setHistory] = useState<HistoryEntry[]>(() => loadHistory());

  useEffect(() => { saveHistory(history); }, [history]);

  const addToHistory = (o: CalcOutput) => {
    const percentText = o.probability !== null ? formatPercent(o.probability) : o.type === 'subjective' ? 'оценка' : '—';
    setHistory((h) => [makeEntry(o.title, o.type, o.summaryForHistory, percentText), ...h].slice(0, 100));
  };

  const runQuery = (text: string) => {
    const a = analyzeQuery(text);
    setAnalysis(a);
    setLastQuery(text);
    if (a.probability !== null) addToHistory(analysisToOutput(a, text));
    document.getElementById('analysis-result')?.scrollIntoView({ behavior: 'smooth', block: 'start' });
  };

  const submitQuery = (e: FormEvent) => {
    e.preventDefault();
    runQuery(query);
  };

  const searchResults = useMemo(() => {
    const s = search.trim().toLowerCase();
    if (!s) return null;
    return {
      calcs: CALCULATORS.filter((c) => `${c.title} ${c.short}`.toLowerCase().includes(s)),
      books: HANDBOOK.filter((a) => `${a.title} ${a.short}`.toLowerCase().includes(s)),
      examples: EXAMPLE_QUERIES.filter((x) => x.query.toLowerCase().includes(s)),
    };
  }, [search]);

  const openCalc = (id: string) => { setCalcId(id); setTab('calc'); window.scrollTo({ top: 0 }); };
  const suggested = analysis?.suggestedCalculator;

  return (
    <div className="app">
      <a className="skip-link" href="#main">К содержанию</a>
      <header className="header">
        <div className="header-inner">
          <div className="brand">
            <span className="brand-mark" aria-hidden="true">%</span>
            <div>
              <strong>Вероятно</strong>
              <span>оценка и изучение вероятностей</span>
            </div>
          </div>
          <nav className="tabs" aria-label="Разделы приложения">
            {TABS.map((t) => (
              <button key={t.id} type="button" className={tab === t.id ? 'tab active' : 'tab'} aria-current={tab === t.id ? 'page' : undefined} onClick={() => setTab(t.id)}>
                {t.label}{t.id === 'history' && history.length > 0 ? ` (${history.length})` : ''}
              </button>
            ))}
          </nav>
        </div>
      </header>

      <main id="main" className="main">
        {tab === 'home' && (
          <>
            <section className="hero">
              <h1>Какова вероятность? Разберём честно</h1>
              <p>
                Некоторые вероятности <strong>вычисляются</strong> (кубик, монета), некоторые <strong>оцениваются по данным</strong> («7 из 10»),
                а некоторые — лишь <strong>субъективный прогноз</strong>. Приложение различает эти случаи, показывает формулу,
                допущения и диапазон неопределённости — и не выдумывает точные проценты для реального мира.
              </p>
              <div className="type-legend" aria-label="Типы оценок">
                <span className="badge badge-exact">Математически вычисляемая</span>
                <span className="badge badge-statistical">Статистическая по данным</span>
                <span className="badge badge-subjective">Субъективный прогноз</span>
              </div>
            </section>

            <section className="panel" aria-labelledby="ask-h">
              <h2 id="ask-h">Опишите событие своими словами</h2>
              <form onSubmit={submitQuery} className="query-form">
                <div className="field grow">
                  <label htmlFor="free-query">Ваш запрос</label>
                  <input
                    id="free-query"
                    value={query}
                    onChange={(e) => setQuery(e.target.value)}
                    placeholder="Например: монетка, кубик, «7 успехов из 10 попыток»…"
                    autoComplete="off"
                  />
                </div>
                <button type="submit" className="btn btn-primary">Оценить</button>
              </form>
              <div className="chips" aria-label="Примеры запросов">
                {EXAMPLE_QUERIES.map((x) => (
                  <button key={x.query} type="button" className="chip" onClick={() => { setQuery(x.query); runQuery(x.query); }}>
                    {x.query} <small>{x.hint}</small>
                  </button>
                ))}
              </div>
              <div id="analysis-result">
                {analysis && (
                  <>
                    <ResultCard result={analysisToOutput(analysis, lastQuery)} />
                    {suggested && (
                      <p className="suggest-row">
                        <button type="button" className="btn btn-ghost" onClick={() => openCalc(suggested)}>
                          Открыть связанный калькулятор: {CALCULATORS.find((c) => c.id === suggested)?.title ?? suggested} →
                        </button>
                      </p>
                    )}
                  </>
                )}
              </div>
            </section>

            <section className="panel" aria-labelledby="search-h">
              <h2 id="search-h">Поиск по приложению</h2>
              <div className="field">
                <label htmlFor="global-search">Найти калькулятор, понятие или пример</label>
                <input id="global-search" value={search} onChange={(e) => setSearch(e.target.value)} placeholder="Например: Байес, ожидание, хотя бы один" autoComplete="off" />
              </div>
              {searchResults && (
                <div className="search-results">
                  {searchResults.calcs.length === 0 && searchResults.books.length === 0 && searchResults.examples.length === 0 && (
                    <p className="empty">Ничего не нашлось. Попробуйте: «Байес», «кубик», «интервал».</p>
                  )}
                  {searchResults.calcs.map((c) => (
                    <button key={c.id} type="button" className="search-item" onClick={() => openCalc(c.id)}>
                      <strong>Калькулятор: {c.title}</strong><span>{c.short}</span>
                    </button>
                  ))}
                  {searchResults.books.map((b) => (
                    <button key={b.id} type="button" className="search-item" onClick={() => setTab('book')}>
                      <strong>Справочник: {b.title}</strong><span>{b.short}</span>
                    </button>
                  ))}
                  {searchResults.examples.map((x) => (
                    <button key={x.query} type="button" className="search-item" onClick={() => { setQuery(x.query); runQuery(x.query); window.scrollTo({ top: 0, behavior: 'smooth' }); }}>
                      <strong>Пример: {x.query}</strong><span>{x.hint}</span>
                    </button>
                  ))}
                </div>
              )}
              {!searchResults && <p className="muted">Поиск ищет по калькуляторам, справочнику и примерам — прямо на этом устройстве.</p>}
            </section>

            <SubjectiveEstimator onSave={addToHistory} />

            <section className="panel info-panel">
              <h2>Как читать результаты</h2>
              <ul className="plain-list">
                <li><strong>Точный процент</strong> бывает только у математической модели с известными шансами. Проверьте допущения под результатом.</li>
                <li><strong>Оценка по данным</strong> всегда смотрите вместе с интервалом: «70% (40–89%)» и «70% (67–73%)» — разная надёжность при одном числе.</li>
                <li><strong>Субъективный прогноз</strong> — это оформленное мнение. В приложении он никогда не маскируется под вычисление.</li>
                <li>История хранится только в localStorage вашего браузера и никуда не отправляется. Удалить её можно на вкладке «История».</li>
              </ul>
            </section>
          </>
        )}

        {tab === 'calc' && (
          <section aria-labelledby="calc-h">
            <h1 id="calc-h" className="page-title">Калькуляторы</h1>
            <p className="muted page-sub">Каждый расчёт показывает тип оценки, формулу, шаги, допущения и ограничения. Результаты автоматически попадают в историю на этом устройстве.</p>
            <Calculators active={calcId} onSelect={setCalcId} onSave={addToHistory} />
          </section>
        )}

        {tab === 'sim' && (
          <section aria-labelledby="sim-h">
            <h1 id="sim-h" className="page-title">Генератор случайных экспериментов</h1>
            <p className="muted page-sub">Монте-Карло в вашем браузере: повторяем эксперимент тысячи раз и смотрим, как частота подбирается к теории.</p>
            <Simulator onSave={addToHistory} />
          </section>
        )}

        {tab === 'book' && (
          <section aria-labelledby="book-h">
            <h1 id="book-h" className="page-title">Справочник понятий</h1>
            <p className="muted page-sub">Простыми словами, с формулой, примером и типичной ошибкой. Используйте поиск на главном экране, чтобы отфильтровать статьи.</p>
            <Handbook query={search} />
          </section>
        )}

        {tab === 'history' && (
          <section aria-labelledby="hist-h">
            <h1 id="hist-h" className="page-title">История расчётов</h1>
            <p className="muted page-sub">Хранится только в этом браузере (localStorage), максимум 100 записей, на сервер не отправляется. Вы можете удалить любую запись или всё сразу.</p>
            {history.length === 0 ? (
              <p className="empty">Пока пусто. Сделайте расчёт на главном экране, в калькуляторах или симуляторе — он появится здесь.</p>
            ) : (
              <>
                <p><button type="button" className="btn btn-danger" onClick={() => { if (window.confirm('Удалить всю историю расчётов на этом устройстве?')) setHistory([]); }}>Удалить всю историю</button></p>
                <ul className="history-list">
                  {history.map((h) => (
                    <li key={h.id} className="history-item">
                      <div>
                        <strong>{h.title}</strong>
                        <span className={`badge badge-${h.type}`}>{ESTIMATE_LABELS[h.type]}</span>
                        <span className="history-percent">{h.percentText}</span>
                        <small>{new Date(h.createdAt).toLocaleString('ru-RU')} · {h.summary}</small>
                      </div>
                      <button type="button" className="btn btn-ghost" onClick={() => setHistory((x) => x.filter((y) => y.id !== h.id))} aria-label={`Удалить запись: ${h.title}`}>Удалить</button>
                    </li>
                  ))}
                </ul>
              </>
            )}
          </section>
        )}
      </main>

      <footer className="footer">
        <p>«Вероятно» — учебный инструмент. Математика точна ровно настолько, насколько верны её допущения; статистика честна ровно настолько, насколько хороши данные. Для решений с последствиями проверяйте исходные данные и консультируйтесь со специалистами.</p>
      </footer>
    </div>
  );
}
